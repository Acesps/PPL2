the code can be compiled and run by running the following command in terminal.

g++ code_part_1.cpp
./a.out
g++ code_part_2.cpp
./a.out

